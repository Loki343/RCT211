//counter
export const ADD = "ADD";
export const REDUCE = "REDUCE";

//todo
//get todo
export const GET_TODO_REQUEST = "GET_TODO_REQUEST";
export const GET_TODO_SUCCESS = "GET_TODO_SUCCESS";
export const GET_TODO_FAILURE = "GET_TODO_FAILURE";
//post/add todo
export const POST_TODO_REQUEST = "POST_TODO_REQUEST";
export const POST_TODO_SUCCESS = "POST_TODO_SUCCESS";
export const POST_TODO_FAILURE = "POST_TODO_FAILURE";