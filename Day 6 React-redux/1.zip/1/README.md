## Redux

Subscribe --> track the state change

Redux React -> No connection -> No hooks

redux -- react-redux -- react

## Steps :-
1. npm i redux
2. npm i react-redux
3. Create basic structure of redux
4. use useSelector to access store
5. use useDispatch to dispatch action